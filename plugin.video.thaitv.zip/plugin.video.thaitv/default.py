import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

def add_item(name, stream_url, logo_url):
    li = xbmcgui.ListItem(label=name)

    # ใส่โลโก้จาก URL
    li.setArt({
        "thumb": logo_url,
        "icon": logo_url,
        "fanart": logo_url
    })

    li.setProperty("IsPlayable", "true")

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=stream_url,
        listitem=li,
        isFolder=False
    )

# ===== เพิ่มช่อง =====
add_item(
    "CH7",
    "https://live-cdn.ch7.com/out/v1/eafeb02c55b64a15b278b1e66c7fc776/playlist.m3u8",
    "https://api.cantstopwontstop.online/images/png/hd-ch7.png"
)

add_item(
    "one31",
    "https://bcovlive-a.akamaihd.net/b6603a14ea59440a95e9235e14bc9332/ap-southeast-1/6415628290001/bdfd964c7fa447a8811f2a3c4ed3ef1c/playlist_ssaiM.m3u8",
    "https://api.cantstopwontstop.online/images/png/hd-gmmone.png"
)

add_item(
    "CH8",
    "https://prsmedia-mykojh.cdn.byteark.com/fleetstream/live/720p/index.m3u8",
    "https://api.cantstopwontstop.online/images/png/hd-ch8.png"
)
add_item(
    "CH3",
    "https://p0.cdn.vet/live/ch3/i/ch3i.m3u8?sid=b5yYTAxM2U3NjVjYjJjYWZhMDI1YQNzY0MWIzYzAzMmU0NmYw",
    "https://api.cantstopwontstop.online/images/png/hd-ch3.png"
)
add_item(
    "mono29",
    "https://monomax-uiripn.cdn.byteark.com/plain/th/1080p/index.m3u8",
    "https://api.cantstopwontstop.online/images/png/hd-mono.png"
)

add_item(
    "thairat tv",
    "https://p1.cdn.vet/live/ch39/i/ch39i.m3u8?sid=b5yMTUwY2I2NGE3ZDIzYmY5NGI4MwMzk3YTc1NTBhM2Q3NWZm",
    "https://api.cantstopwontstop.online/images/png/hd-thairath.png"
)
add_item(
    "workpiont",
    "https://live-global-cdn-v02.sooplive.co.kr/live-stmc-39/auth_master_playlist.m3u8?aid=.A32.pxqRXFPZNcY9Qg1.weKg0SrZF9r0XVHoAOdfRtAHFCfG0IR6n8tRTXILBs3rDJiUDP3kkILQU_MkT5KOLUaSQ4FEMXLC-y5IaVrGdxOJ8p72eirmKBeglCKdmr18Kg4EIl7jE5Kx6feBbeShT599SlYiW0LYv_p_aZP2JzzK9ugXnT2768Bl5uGfYSSVlYJKlwOU6A9z8kDMASRMv4jtBPRb41F-Q5j-E8CtEw",
    "https://api.cantstopwontstop.online/images/png/hd-workpoint.png"
)
add_item(
    "Amerin tv",
    "https://amarin-ks7jcc.cdn.byteark.com/live/playlist.m3u8?x_ark_access_id=fleet-868&x_ark_auth_type=ark-v2&x_ark_expires=1768715019&x_ark_path_prefix=%2Flive%2F&x_ark_signature=y5l_LQ_-Oh0Rmy_UrjRsUg",
    "https://api.cantstopwontstop.online/images/png/hd-amarin.png"
)
add_item(
    "ThaiPBS",
    "https://thaipbs-live.cdn.byteark.com/live/playlist.m3u8",
    "https://api.cantstopwontstop.online/images/png/hd-tpbs.png"
)

xbmcplugin.endOfDirectory(addon_handle)
